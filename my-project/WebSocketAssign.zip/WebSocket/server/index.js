const http = require('http').createServer(); //build in HTTP library in node!
const fs = require('fs');

const io = require('socket.io')(http, {
    cors: { origin : "*" }
});


io.on('connection', socket => {

    console.log('A User Connected!');

    socket.on('message', message => {

        console.log(message);
        let display = `${socket.id.substr(0,2)} Says:  ${message}`;
        io.emit('message', display);

        display += '\n';
        fs.appendFileSync('data.txt', display);

    });

});


http.listen(8080, () => console.log('listening on http://localhost:8080 ') );