const socket = io('ws://localhost:8080');

socket.on('message', text => {

    const el = document.createElement('li');
    el.innerHTML = text;
    el.style.marginLeft = '500px';
    document.querySelector('ul').append(el);
    
});

document.getElementById('btn').onclick = () => {


    if(document.querySelector('input').value != ''){
        const text = document.querySelector('input').value;
        socket.emit('message', text);
        document.querySelector('input').value = '';

    }

}
document.addEventListener('keydown', (e) => {
    
    if(e.key === 'Enter' && document.querySelector('input').value != ''){
        const text = document.querySelector('input').value;
        socket.emit('message', text);
        document.querySelector('input').value = '';

    }

});

